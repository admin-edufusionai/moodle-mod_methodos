<?php
/**
 * Moodle Methodos plugin version details.
 *
 * @package    mod_methodos
 * @copyright  2026 Methodos Peer Review
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026102201;       // The current module version (YYYYMMDDXX).
$plugin->requires  = 2022112800;       // Requires Moodle 4.1.0 LTS (compatible up to 4.5+).
$plugin->component = 'mod_methodos';   // Full name of the plugin (must match folder name).
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = 'v1.1.7';
